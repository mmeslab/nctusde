// Example: Homepage
pref("browser.startup.homepage", "file:/etc/linaro/ffox-homepage.properties");

